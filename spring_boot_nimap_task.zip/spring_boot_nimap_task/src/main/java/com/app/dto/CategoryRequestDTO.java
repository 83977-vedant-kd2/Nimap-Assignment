package com.app.dto;

import lombok.Data;

@Data
public class CategoryRequestDTO {
    private String name;
    
}